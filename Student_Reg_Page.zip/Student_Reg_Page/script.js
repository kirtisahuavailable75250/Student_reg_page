// Wait for the DOM content to be fully loaded before running the script
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('studentForm'); // The form element for student registration
    const studentRecords = document.getElementById('studentRecords'); // The section where student records will be displayed

    // Load existing records from local storage
    loadRecords();

    // Handle form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault(); // Prevent the default form submission behavior

        // Get form values and trim any leading/trailing whitespace
        const name = document.getElementById('name').value.trim();
        const id = document.getElementById('id').value.trim();
        const email = document.getElementById('email').value.trim();
        const contact = document.getElementById('contact').value.trim();

        // Validate input fields
        if (!name || !id || !email || !contact) {
            alert('Please fill all fields.'); // Alert if any field is empty
            return;
        }

        // Validate student name to contain only letters and spaces
        if (!/^[a-zA-Z\s]+$/.test(name)) {
            alert('Name must contain only letters.'); // Alert if name contains non-letters
            return;
        }

        // Validate contact number to be exactly 10 digits
        if (!/^[0-9]{10}$/.test(contact)) {
            alert('Contact number must be exactly 10 digits.'); // Alert if contact number is invalid
            return;
        }

        // Check if a record with the same ID already exists
        if (document.querySelector(`.student-record[data-id="${id}"]`)) {
            alert('Student ID already exists.'); // Alert if ID already exists
            return;
        }

        // Create a new student record object
        const record = {
            name,
            id,
            email,
            contact
        };

        // Add the record to the display and save it in local storage
        addRecord(record);
        saveRecord(record);
        form.reset(); // Reset the form fields
    });

    // Function to add a student record to the display
    function addRecord(record) {
        // Create a new div element for the student record
        const div = document.createElement('div');
        div.classList.add('student-record'); // Add a class for styling
        div.dataset.id = record.id; // Store the student ID in a data attribute
        div.innerHTML = `
            <strong>${record.name}</strong> (ID: ${record.id})<br>
            Email: ${record.email}<br>
            Contact: ${record.contact}<br>
            <button onclick="editRecord('${record.id}')">Edit</button>
            <button onclick="deleteRecord('${record.id}')">Delete</button>
        `;
        studentRecords.appendChild(div); // Add the new record to the studentRecords section
    }

    // Function to save a student record to local storage
    function saveRecord(record) {
        // Retrieve existing records or initialize an empty array
        let records = JSON.parse(localStorage.getItem('studentRecords')) || [];
        records.push(record); // Add the new record to the array
        localStorage.setItem('studentRecords', JSON.stringify(records)); // Save the updated array back to local storage
    }

    // Function to load student records from local storage and display them
    function loadRecords() {
        // Retrieve existing records or initialize an empty array
        let records = JSON.parse(localStorage.getItem('studentRecords')) || [];
        records.forEach(record => addRecord(record)); // Add each record to the display
    }

    // Function to edit a student record
    window.editRecord = function(id) {
        // Retrieve existing records from local storage
        const records = JSON.parse(localStorage.getItem('studentRecords')) || [];
        const record = records.find(record => record.id === id); // Find the record to edit
        if (record) {
            // Populate the form with the existing record data
            document.getElementById('name').value = record.name;
            document.getElementById('id').value = record.id;
            document.getElementById('email').value = record.email;
            document.getElementById('contact').value = record.contact;
            // Remove the record from local storage and the display
            const updatedRecords = records.filter(record => record.id !== id);
            localStorage.setItem('studentRecords', JSON.stringify(updatedRecords));
            document.querySelector(`.student-record[data-id="${id}"]`).remove();
        }
    };

    // Function to delete a student record
    window.deleteRecord = function(id) {
        // Retrieve existing records from local storage
        const records = JSON.parse(localStorage.getItem('studentRecords')) || [];
        // Filter out the record to delete
        const updatedRecords = records.filter(record => record.id !== id);
        localStorage.setItem('studentRecords', JSON.stringify(updatedRecords)); // Update local storage
        document.querySelector(`.student-record[data-id="${id}"]`).remove(); // Remove the record from the display
    };
});
